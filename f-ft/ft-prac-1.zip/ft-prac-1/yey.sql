CREATE DATABASE shipment_db;
USE shipment_db;

ALTER table shipments_tbl
MODIFY shipment_id varchar(20) PRIMARY KEY