CREATE DEFINER=`root`@`localhost` FUNCTION `proper_case`(str VARCHAR(255)) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    DETERMINISTIC
BEGIN
  DECLARE c CHAR(1);
  DECLARE s VARCHAR(255);
  DECLARE i INT DEFAULT 1;
  DECLARE bool INT DEFAULT 1;
  DECLARE punct CHAR(17) DEFAULT ' ()[]{},.-_!@;:?/';
  
  SET s = LCASE(str);
  WHILE i <= LENGTH(str) DO
    SET c = SUBSTRING(s, i, 1);
    IF LOCATE(c, punct) > 0 THEN
      SET bool = 1;
    ELSEIF bool = 1 THEN
      IF c >= 'a' AND c <= 'z' THEN
        SET s = CONCAT(LEFT(s, i-1), UCASE(c), SUBSTRING(s, i+1));
        SET bool = 0;
      END IF;
    END IF;
    SET i = i + 1;
  END WHILE;
  RETURN s;
END