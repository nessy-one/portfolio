SELECT * FROM dirty_shipments;
-- 1. REMOVE Leading and Trailing spaces and covert to upper case
SELECT shipment_id,
	proper_case(trim(origin_warehouse)) AS origin_warehouse,
	proper_case(trim(destination_city)) AS destination_city,
    ucase(destination_state) AS destination_state,
    proper_case(trim(carrier) AS carrier,
    
-- 2. Change DATE format for ship_date and delivery_date
    str_to_date(delivery_date, '%Y-%m-%d') AS delivery_date,
    str_to_date(ship_date, '%Y-%m-%d') AS ship_date,
    
-- 3. Validate Date entries for delivery and shipment
datediff(delivery_date, ship_date) AS No_of_days_delivered,
CASE
	WHEN(delivery_date) < (ship_date) THEN 'Invalid'
	WHEN(delivery_date) = (ship_date) THEN 'Same Day Delivery'
	ELSE 'valid'
END as delivery_status,

-- 4. Validate Weights_kg
CASE
	WHEN weight_kg < 0 THEN abs (weight_kg)
    WHEN weight_kg = 0 THEN abs (weight_kg)
	ELSE weight_kg
END AS valid_weight,

-- 5. Look for Duplicates abd Remove using Row_Num window function in SQL
row_number() over(
	partition by origin_warehouse, destination_city, destination_state, 
	ship_date, carrier, 
	CONVERT(weight_kg, char),
	CONVERT(freight_cost, char)
ORDER BY shipment_id) as row_num     

FROM shipment_db.dirty_shipments;

-- 6. REMOVE DUPLICATES
DELETE FROM dirty_shipments
	WHERE shipment_id IN 
    (
    SELECT shipment_id FROM (
		SELECT shipment_id, ROW_NUMBER() OVER
        (PARTITION BY origin_warehouse, destination_city, carrier,
        ship_date ORDER BY shipment_id) as row_num
        FROM dirty_shipments
	) as sub
        WHERE row_num > 1
);